package mydefault.androidapp;


import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class now_activity extends Activity{
    private GridView gridView;

    private ImageButton backButton;
    private ArrayList<String> list;
    private ArrayAdapter<String> adapter;
    database_handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.now_layout);
        //GridView
        gridView=(GridView) findViewById(R.id.gridView);
        //   gridView.setChoiceMode(GridView.CHOICE_MODE_SINGLE);
        //ArrayList
        list=new ArrayList<String>();
        adapter=new ArrayAdapter<String>
                (getApplicationContext(),android.R.layout.simple_spinner_item,list);

        handler=new database_handler(getBaseContext());//getting the context object
        handler.open();
        try
        {
            //for holding retrieve data from query and store in the form of rows
            Cursor c=handler.displaynow();
            //Move the cursor to the first row.
            if(c.moveToFirst())
            {
                do
                {
                    //add in to array list
                    list.add(c.getString(c.getColumnIndex("_id")));
                    list.add(c.getString(c.getColumnIndex("daterecord")));
                    list.add(c.getString(c.getColumnIndex("theme")));

                    gridView.setAdapter(adapter);
                }while(c.moveToNext());//Move the cursor to the next row.
            }
            else
            {
                Toast.makeText(getApplicationContext(), "Данные не найдены", Toast.LENGTH_LONG).show();
            }
        }catch(Exception e)
        {
            Toast.makeText(getApplicationContext(), "Данные не найдены"+e.getMessage(), Toast.LENGTH_LONG).show();
        }
        handler.close();
        //Toast.makeText(getBaseContext(),"Name: "+name+"Roll No: "+roll+"Course: "+cour



        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //Toast.makeText(getBaseContext(), "ID:"+o.toString(), Toast.LENGTH_LONG).show();
                Intent i=new Intent(now_activity.this, recordedit_activity.class);

                long   temp=(position/gridView.getNumColumns())*gridView.getNumColumns();
                Object o = gridView.getItemAtPosition((int)temp);
                i.putExtra("id", o.toString());
                temp++;
                o = gridView.getItemAtPosition((int)temp);
                i.putExtra("daterecord", o.toString());
                temp++;
                o = gridView.getItemAtPosition((int)temp);
                i.putExtra("theme", o.toString());

                i.putExtra("back", "now");
                startActivity(i);//start activity
            }
        });



        backButton  =(ImageButton) findViewById(R.id.imgbtn2);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(now_activity.this, main_activity.class);
                startActivity(i);//start activity
            }
        });
    }


}
