package mydefault.androidapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;


public class main_activity extends Activity {


    private Button enter_button;
    database_handler handler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);


    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        if (id == R.id.action_exit) {
            finishAffinity();
            System.exit(0);
            return true;
        }

        if (id == R.id.action_record) {
            Intent i=new Intent(this,record_activity.class);
            startActivity(i);//start activity
            return true;
        }

        if (id == R.id.action_now) {
            Intent i=new Intent(this,now_activity.class);
            startActivity(i);//start activity
            return true;
        }

        if (id == R.id.action_week) {
            Intent i=new Intent(this,week_activity.class);
            startActivity(i);//start activity
            return true;
        }

        if (id == R.id.action_alarm) {
            Intent i=new Intent(this,setalarm_avtivity.class);
            startActivity(i);//start activity
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
