package mydefault.androidapp;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.Time;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;


public class setalarm_avtivity extends Activity {

    private EditText hourEditText, minuteEditText;
    private ImageButton setbutton;
    private ImageButton backButton;
    private ImageButton imageButtonUp1,imageButtonUp2,imageButtonDown1,imageButtonDown2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.setalarm_layout);

        hourEditText=(EditText) findViewById(R.id.editText1);
        minuteEditText=(EditText) findViewById(R.id.editText2);

        setbutton=(ImageButton)findViewById(R.id.imgbtn2);
        backButton=(ImageButton)findViewById(R.id.imgbtn1);

        imageButtonUp1=(ImageButton)findViewById(R.id.imageButton1);
        imageButtonDown1=(ImageButton)findViewById(R.id.imageButton2);
        imageButtonUp2=(ImageButton)findViewById(R.id.imageButton4);
        imageButtonDown2=(ImageButton)findViewById(R.id.imageButton3);


        Time now = new Time();
        now.setToNow();

        hourEditText.setText(now.format("%H"));
        minuteEditText.setText(now.format("%M"));

        setbutton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {



            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.SECOND, 0);
            calendar.set(Calendar.MILLISECOND, 0);
            calendar.set(Calendar.MINUTE, Integer.parseInt(minuteEditText.getText().toString()));
            calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hourEditText.getText().toString()));

            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            AlarmManager.AlarmClockInfo alarmClockInfo = new AlarmManager.AlarmClockInfo(calendar.getTimeInMillis(), getAlarmInfoPendingIntent());

            alarmManager.setAlarmClock(alarmClockInfo, getAlarmActionPendingIntent());

            Context context= getBaseContext();
            Toast.makeText(context, "Будильник установлен на " + sdf.format(calendar.getTime()), Toast.LENGTH_SHORT).show();
        }
    });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(setalarm_avtivity.this, main_activity.class);
                startActivity(i);//start activity
            }
        });


        imageButtonUp1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour=Integer.parseInt(hourEditText.getText().toString());
                hour=(hour+1)%24;
                hourEditText.setText(String.format("%02d", hour));
            }
        });

        imageButtonUp2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int minute=Integer.parseInt(minuteEditText.getText().toString());
                minute=(minute+1)%60;
                minuteEditText.setText(String.format("%02d", minute));
            }
        });

        imageButtonDown1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int hour=Integer.parseInt(hourEditText.getText().toString());
                if (hour==0)
                    hour=23;
                else
                    hour=hour-1;
                hourEditText.setText(String.format("%02d", hour));
            }
        });

        imageButtonDown2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int minute=Integer.parseInt(minuteEditText.getText().toString());
                if (minute==0)
                    minute=59;
                else
                    minute=minute-1;
                minuteEditText.setText(String.format("%02d", minute));
            }
        });
    }

    private PendingIntent getAlarmInfoPendingIntent() {
        Intent alarmInfoIntent = new Intent(this, setalarm_avtivity.class);
        alarmInfoIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(this, 0, alarmInfoIntent, PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private PendingIntent getAlarmActionPendingIntent() {
        Intent intent = new Intent(this, alarm_activity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        return PendingIntent.getActivity(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
    }


}
