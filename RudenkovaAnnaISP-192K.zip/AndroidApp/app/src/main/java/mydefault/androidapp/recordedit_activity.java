package mydefault.androidapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;


public class recordedit_activity extends Activity {
    private EditText recordEditText, themeEditText, datecreateEditText, daterecordEditText;
    private Spinner spinner_post;
    private ImageButton insertButton;
    private ImageButton cancelButton;
    private ImageButton deleteButton;

    database_handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recordedit_layout);
        recordEditText=(EditText) findViewById(R.id.EditText4);
        themeEditText=(EditText) findViewById(R.id.EditText2);
        datecreateEditText=(EditText) findViewById(R.id.EditText1);
        daterecordEditText=(EditText) findViewById(R.id.EditText3);
        insertButton=(ImageButton) findViewById(R.id.imgbtn2);
        cancelButton=(ImageButton) findViewById(R.id.imgbtn1);
        deleteButton=(ImageButton) findViewById(R.id.imgbtn3);


        String id = getIntent().getExtras().getString("id");
        String theme = getIntent().getExtras().getString("theme");
        String daterecord = getIntent().getExtras().getString("daterecord");

        handler=new database_handler(getBaseContext());//getting the context object
        handler.open();
        Cursor c=handler.getrecord(id);

        String datecreate= "";
        String record= "";
        if(c.moveToFirst())
        {
            datecreate= c.getString(c.getColumnIndex("datecreate"));
            record= c.getString(c.getColumnIndex("record"));
        }


        handler.close();

        recordEditText.setText(record);
        themeEditText.setText(theme);
        datecreateEditText.setText(datecreate);
        daterecordEditText.setText(daterecord);


        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id = getIntent().getExtras().getString("id");
                String record=recordEditText.getText().toString();
                String theme=themeEditText.getText().toString();
                String datecreate=datecreateEditText.getText().toString();
                String daterecord=daterecordEditText.getText().toString();

                handler=new database_handler(getBaseContext());//getting the context object
                handler.open();
                handler.updaterecord(id, record, theme, datecreate, daterecord);
                handler.close();

                Intent i;
                String back= getIntent().getExtras().getString("back");

                i=new Intent(recordedit_activity.this,record_activity.class);
                if  (back.equalsIgnoreCase("now"))
                    i=new Intent(recordedit_activity.this,now_activity.class);
                if  (back.equalsIgnoreCase("week"))
                    i=new Intent(recordedit_activity.this,week_activity.class);

                startActivity(i);//start activity
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent;
                String back= getIntent().getExtras().getString("back");

                intent=new Intent(recordedit_activity.this,record_activity.class);
                if  (back.equalsIgnoreCase("now"))
                    intent=new Intent(recordedit_activity.this,now_activity.class);
                if  (back.equalsIgnoreCase("week"))
                    intent=new Intent(recordedit_activity.this,week_activity.class);
                startActivity(intent);//start activity
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(recordedit_activity.this);
                builder.setTitle("Удалить запись?");
                builder.setMessage("Вы уверены, что хотите удалить запись?");
                builder.setPositiveButton("Да", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        String id = getIntent().getExtras().getString("id");

                        handler=new database_handler(getBaseContext());//getting the context object
                        handler.open();
                        handler.deleterecord(id);
                        handler.close();

                        Intent intent;
                        String back= getIntent().getExtras().getString("back");

                        intent=new Intent(recordedit_activity.this,record_activity.class);
                        if  (back.equalsIgnoreCase("now"))
                            intent=new Intent(recordedit_activity.this,now_activity.class);
                        if  (back.equalsIgnoreCase("week"))
                            intent=new Intent(recordedit_activity.this,week_activity.class);
                        startActivity(intent);//start activity

                        finish();
                    }
                });
                builder.setNegativeButton("Нет", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                builder.create().show();





            }
        });
    }
}
