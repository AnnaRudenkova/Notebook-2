package mydefault.androidapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

import android.text.format.Time;

public class recordadd_activity extends Activity{
    private EditText recordEditText, themeEditText, datecreateEditText, daterecordEditText;
    private Spinner spinner_post;
    private ImageButton insertButton;
    private ImageButton cancelButton;

    database_handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recordadd_layout);
        recordEditText=(EditText) findViewById(R.id.EditText4);
        themeEditText=(EditText) findViewById(R.id.EditText2);
        datecreateEditText=(EditText) findViewById(R.id.EditText1);
        daterecordEditText=(EditText) findViewById(R.id.EditText3);
        insertButton=(ImageButton) findViewById(R.id.imgbtn2);
        cancelButton=(ImageButton) findViewById(R.id.imgbtn1);

        Time now = new Time();
        now.setToNow();

        datecreateEditText.setText(now.format("%Y-%m-%d"));
        daterecordEditText.setText(now.format("%Y-%m-%d"));

        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String record=recordEditText.getText().toString();
                String theme=themeEditText.getText().toString();
                String datecreate=datecreateEditText.getText().toString();
                String daterecord=daterecordEditText.getText().toString();

                handler=new database_handler(getBaseContext());//getting the context object
                handler.open();
                handler.insertrecord(record, theme, datecreate, daterecord);
                handler.close();

                Intent i=new Intent(recordadd_activity.this,record_activity.class);
                startActivity(i);//start activity
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(recordadd_activity.this,record_activity.class);
                startActivity(i);//start activity
            }
        });
    }
}
