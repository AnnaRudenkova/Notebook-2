package mydefault.androidapp;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

public class database_handler {

    public static final String DATABASE_NAME="androidappdb";
    public static final int DATABASE_VERSION=3;
    //Table query
    public static final String TABLE_CREATE=
            " CREATE TABLE record (idrecord INTEGER PRIMARY KEY AUTOINCREMENT, daterecord DATE, datecreate DATE, theme varchar (80), record varchar (800));";

    DataBaseHelper dbhelper;
    Context context;
    SQLiteDatabase db;



    public database_handler(Context ctx)
    {
        this.context=ctx;
        dbhelper=new DataBaseHelper(context);
    }



    private static class DataBaseHelper extends SQLiteOpenHelper
    {
        //Create a helper object to create, open, and/or manage a database.
        public DataBaseHelper(Context ctx)
        {
            super(ctx,DATABASE_NAME,null,DATABASE_VERSION);
        }
        @Override
        //Called when the database is created for the first time.
        public void onCreate(SQLiteDatabase db)
        {

            db.execSQL(TABLE_CREATE);//Here create a table

        }
        @Override
        //Called when the database needs to be upgraded.
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS record");

            onCreate(db);
        }
    }
    public database_handler open()
    {
        //Create and/or open a database that will be used for reading and writing.
        db=dbhelper.getWritableDatabase();

        return this;
    }
    public void close()
    {
        //Close any open database object.
        dbhelper.close();
    }

    //record//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //Insert record in the database
    public void insertrecord(String record,String theme,String datecreate,String daterecord)
    {
        //This class is used to store a set of values
        ContentValues content=new ContentValues();
        content.put("record", record);
        content.put("theme", theme);
        content.put("datecreate", datecreate);
        content.put("daterecord", daterecord);
        long result =  db.insertOrThrow("record",null, content);
        if(result == -1){
            Toast.makeText(context, "Ошибка добавления данных", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Данные успешно добавлены", Toast.LENGTH_SHORT).show();
        }
    }

    public void updaterecord(String id, String record,String theme,String datecreate,String daterecord)
    {
        //This class is used to store a set of values
        ContentValues content=new ContentValues();
        content.put("record", record);
        content.put("theme", theme);
        content.put("datecreate", datecreate);
        content.put("daterecord", daterecord);
        long result =  db.update("record", content, "idrecord=?", new String[]{id});
        if(result == -1){
            Toast.makeText(context, "Ошибка редактирования данных", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Данные успешно отредактированы", Toast.LENGTH_SHORT).show();
        }
    }

    public void deleterecord(String id) {
        //This class is used to store a set of values
        ContentValues content=new ContentValues();

        long result =  db.delete("record", "idrecord=?", new String[]{id});
        if(result == -1){
            Toast.makeText(context, "Ошибка удаления данных", Toast.LENGTH_SHORT).show();
        }else {
            Toast.makeText(context, "Данные успешно удалены", Toast.LENGTH_SHORT).show();
        }
    }

    //Display record from the database
    public Cursor displayrecord()
    {
        //Select query
        return db.rawQuery("SELECT idrecord as _id, theme, daterecord FROM record order by daterecord ASC", null);
    }

    public Cursor displaynow()
    {
        //Select query
        return db.rawQuery("SELECT idrecord as _id, theme, daterecord FROM record where daterecord=strftime('%Y-%m-%d', datetime('now')) order by daterecord ASC", null);
    }

    public Cursor displayweek()
    {
        //Select query
        return db.rawQuery("SELECT idrecord as _id, theme, daterecord FROM record WHERE DATE(daterecord) >= DATE('now', 'weekday 0', '-6 days') AND  DATE(daterecord) <= DATE('now', 'weekday 0') order by daterecord ASC", null);
    }

    //Display record from the database
    public Cursor getrecord(String id)
    {
        //Select query
        return db.rawQuery("SELECT record,  datecreate FROM record where idrecord="+id, null);
    }



}
